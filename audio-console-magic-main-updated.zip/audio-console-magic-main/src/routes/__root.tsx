import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useNavigate,
  useRouterState,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, useRef, type ReactNode } from "react";

import { cloudConfigured, needsLogin, startAuth, useAuth, useEmbedded } from "../lib/mk/cloud";
import { isLocked, useAccess } from "../lib/mk/roles";
import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "MK VISION" },
      { name: "description", content: "MK VISION: live production desk" },
      { name: "author", content: "MK VISION" },
      { property: "og:title", content: "MK VISION" },
      { property: "og:description", content: "MK VISION: live production desk" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    scripts: [
      {
        // Inside MK VISION Studio the built-in engine publishes its connection details at
        // /mk-config.json (same origin, this PC only). Apply them before the app starts so
        // nothing has to be typed in. A crew desk opened from the Director's address (port 17870)
        // takes the engine address from the page address and the password / desk from the link.
        // On any other host this quietly does nothing.
        children:
          '(function(){try{var k="mkvision.config.v1",s={};try{s=JSON.parse(localStorage.getItem(k)||"{}")||{}}catch(e){}var x=new XMLHttpRequest();x.open("GET","/mk-config.json",false);x.send();var c=null;if(x.status===200){try{c=JSON.parse(x.responseText)}catch(e){}}if(c&&c.mk===1&&typeof c.port==="number"){s.host=String(c.host||"127.0.0.1");s.port=c.port;s.password=String(c.password||"");s.autoConnect=true;s.demoMode=false;localStorage.setItem(k,JSON.stringify(s));localStorage.setItem("mkvision.engine.v1",JSON.stringify({crew:!!c.crew,lan:c.lan||[],crewPort:c.crewPort||0}));window.__MK_EMBEDDED__=true}else if(location.port==="17870"){var h=location.hash||"",m=h.match(/mkpw=([^&]*)/),pt=h.match(/mkport=(\\d+)/),r=h.match(/role=([a-z]+)/);s.host=location.hostname;s.port=pt?Number(pt[1]):(s.port&&s.host===location.hostname?s.port:4455);s.autoConnect=true;s.demoMode=false;if(m)s.password=decodeURIComponent(m[1]);localStorage.setItem(k,JSON.stringify(s));if(r&&/^(director|graphics|sound|prompter)$/.test(r[1]))localStorage.setItem("mkvision.role.v1",r[1]);if((m||r||pt)&&history.replaceState)history.replaceState(null,"",location.pathname+location.search);window.__MK_EMBEDDED__=true}}catch(e){}})();',
      },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Chakra+Petch:wght@400;600;700&family=JetBrains+Mono:wght@400;600&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

/** A locked desk (crew link) cannot wander to the switcher or other desks' pages. */
function LockGuard() {
  const { route } = useAccess();
  const path = useRouterState({ select: (st) => st.location.pathname });
  const navigate = useNavigate();
  const blocked = !route(path);
  // With accounts set up, the control pages need a login (output / camera pages stay open for OBS and phones).
  const auth = useAuth();
  useEffect(() => {
    void startAuth();
  }, []);
  const embedded = useEmbedded();
  const mustSignIn = cloudConfigured() && auth.ready && !auth.id && needsLogin(path, embedded);
  // Where this guard wants the user to be right now (null = already fine). Never "redirect" to the page we are on.
  const target = mustSignIn ? "/login" : blocked ? "/" : null;
  const tries = useRef<number[]>([]);
  useEffect(() => {
    if (!target || target === path) return;
    // Loop breaker: if redirects keep firing (e.g. sign-in state flapping), stop after 8 in 2s instead of
    // exhausting React's update depth and leaving a blank screen. The state is logged so it can be traced.
    const now = Date.now();
    tries.current = [...tries.current.filter((t) => now - t < 2000), now];
    if (tries.current.length > 8) {
      console.error(
        "[LockGuard] redirect loop stopped " +
          JSON.stringify({
            path,
            target,
            href: window.location.href,
            authReady: auth.ready,
            signedIn: !!auth.id,
            role: auth.role,
            locked: isLocked(),
            mustSignIn,
            blocked,
            cloud: cloudConfigured(),
          }),
      );
      return;
    }
    void navigate({ to: target, replace: true });
  }, [target, path, navigate, auth.ready, auth.id, auth.role, mustSignIn, blocked]);
  return null;
}

/** Nothing of a control page is drawn (or connects to OBS) until the login check passes. */
function Guarded({ children }: { children: ReactNode }) {
  const auth = useAuth();
  const { route } = useAccess();
  const path = useRouterState({ select: (st) => st.location.pathname });
  const embedded = useEmbedded();
  if (cloudConfigured() && needsLogin(path, embedded) && (!auth.ready || !auth.id)) return null;
  if (!route(path)) return null;
  return <>{children}</>;
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
      <LockGuard />
      <Guarded>
        <Outlet />
      </Guarded>
    </QueryClientProvider>
  );
}
